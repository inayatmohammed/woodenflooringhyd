# Wooden flooring in Hyderabad (One-Page Next.js Site)

A single-page, SEO-optimised website for wooden flooring in Hyderabad, built with Next.js 14 (App Router) and ready for Vercel.

## Project structure

```
app/
  layout.js      Global metadata (title, description, Open Graph, Twitter, robots), fonts
  page.js        The one-page site + LocalBusiness / FAQ JSON-LD schema
  globals.css    Styles (warm walnut/oak palette, responsive)
  sitemap.js     /sitemap.xml
  robots.js      /robots.txt
lib/
  business.js    ALL business details (name, phone, emails, address, services, FAQs)
```

To change any contact detail, service, or FAQ, edit `lib/business.js` only.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Deploy to Vercel

1. Push this folder to a GitHub/GitLab/Bitbucket repository.
2. Go to https://vercel.com/new, import the repository, and click **Deploy**. Vercel detects Next.js automatically; no configuration is needed.
3. Add environment variables in **Project Settings → Environment Variables** (optional but recommended):

| Variable | Example | Purpose |
| --- | --- | --- |
| `NEXT_PUBLIC_SITE_URL` | `https://www.galaxydesign.in` | Canonical URL, sitemap, Open Graph and schema URLs |
| `GOOGLE_SITE_VERIFICATION` | `abc123...` | Google Search Console ownership token |
| `BING_SITE_VERIFICATION` | `xyz789...` | Bing Webmaster Tools token |

4. Attach your domain under **Project Settings → Domains**.

## SEO checklist after launch

- Submit `https://<your-domain>/sitemap.xml` in Google Search Console and Bing Webmaster Tools.
- Create or claim a **Google Business Profile** for the Sri Sai Nagar showroom, with the same name, address and phone number used on the site. This is the single biggest factor for "flooring near me" searches in Hyderabad.
- Add real product photos (see "Adding photos" below) with descriptive alt text.
- Ask satisfied clients for Google reviews and, if you have permission, add real testimonials.
- Keep NAP (Name, Address, Phone) identical across the website, Google Business Profile, Justdial, IndiaMART and social profiles.

## Adding photos

The page uses CSS-based visuals so it loads fast with no external images. To add real photos, place them in `public/` and use `next/image`:

```jsx
import Image from "next/image";
<Image src="/images/hardwood-oak.jpg" alt="Oak hardwood flooring installed in a Hyderabad living room" width={1200} height={800} />
```

Only use photos you own or have rights to.

## Contact form

The contact section uses call, WhatsApp, and email links, which need no backend. If you want an on-site form, a service such as Formspree, Web3Forms, or a Next.js Route Handler with an email provider can be added to the `contact` section.
