import { Playfair_Display, Inter } from "next/font/google";
import "./globals.css";
import { SITE_URL } from "../lib/business";

const display = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap",
});

const body = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});


const TITLE =
  "Wooden Flooring in Hyderabad | Laminate, Engineered & Hardwood Supply and Fitting";
const DESCRIPTION =
  "Wooden flooring in Hyderabad: laminate, engineered wood, solid hardwood, SPC and vinyl planks, with professional fitting. Call or WhatsApp for a free quotation.";

export const metadata = {
  metadataBase: new URL(SITE_URL),
  title: TITLE,
  description: DESCRIPTION,
  applicationName: "Wooden flooring in Hyderabad",
  keywords: [
    "wooden flooring Hyderabad",
    "wood flooring Hyderabad",
    "laminate flooring Hyderabad",
    "engineered wood flooring Hyderabad",
    "hardwood flooring Hyderabad",
    "SPC flooring Hyderabad",
    "vinyl wood flooring Hyderabad",
    "flooring installation Hyderabad",
    "Wooden flooring in Hyderabad",
  ],
  authors: [{ name: "Wooden flooring in Hyderabad" }],
  creator: "Wooden flooring in Hyderabad",
  publisher: "Wooden flooring in Hyderabad",
  category: "Home Improvement",
  alternates: {
    canonical: "/",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
      "max-video-preview": -1,
    },
  },
  openGraph: {
    type: "website",
    locale: "en_IN",
    url: "/",
    siteName: "Wooden flooring in Hyderabad",
    title: TITLE,
    description: DESCRIPTION,
  },
  twitter: {
    card: "summary_large_image",
    title: TITLE,
    description: DESCRIPTION,
  },
  verification: {
    google: process.env.GOOGLE_SITE_VERIFICATION,
    other: process.env.BING_SITE_VERIFICATION
      ? { "msvalidate.01": process.env.BING_SITE_VERIFICATION }
      : undefined,
  },
  formatDetection: {
    telephone: true,
    email: true,
    address: true,
  },
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#4a2e1b",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en-IN" className={`${display.variable} ${body.variable}`}>
      <body>{children}</body>
    </html>
  );
}
