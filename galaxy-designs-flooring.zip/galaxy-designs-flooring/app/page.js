import { business, SITE_URL } from "../lib/business";

const WHATSAPP_HREF = `https://wa.me/${business.whatsapp}?text=${encodeURIComponent(
  business.whatsappMessage
)}`;
const MAPS_HREF = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
  business.address.mapsQuery
)}`;

const jsonLd = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "LocalBusiness",
      "@id": `${SITE_URL}/#business`,
      name: business.name,
      description: business.tagline,
      url: SITE_URL,
      telephone: business.phoneTel,
      email: business.primaryEmail,
      address: {
        "@type": "PostalAddress",
        streetAddress: business.address.streetAddress,
        addressLocality: business.address.locality,
        addressRegion: business.address.region,
        postalCode: business.address.postalCode,
        addressCountry: business.address.country,
      },
      areaServed: [
        { "@type": "City", name: "Hyderabad" },
        { "@type": "State", name: "Telangana" },
      ],
      hasOfferCatalog: {
        "@type": "OfferCatalog",
        name: "Wooden Flooring",
        itemListElement: business.services.map((s) => ({
          "@type": "Offer",
          itemOffered: { "@type": "Service", name: s.name, description: s.description },
        })),
      },
    },
    {
      "@type": "WebSite",
      "@id": `${SITE_URL}/#website`,
      url: SITE_URL,
      name: business.name,
      inLanguage: "en-IN",
    },
    {
      "@type": "FAQPage",
      "@id": `${SITE_URL}/#faq`,
      mainEntity: business.faqs.map((f) => ({
        "@type": "Question",
        name: f.question,
        acceptedAnswer: { "@type": "Answer", text: f.answer },
      })),
    },
  ],
};

const reasonIcons = ["★", "◎", "⚒"];

export default function HomePage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <header className="site-header">
        <div className="container">
          <a href="#top" className="brand">
            Wooden flooring in <span>Hyderabad</span>
          </a>
          <nav className="nav" aria-label="Primary">
            <a href="#flooring">Floor Types</a>
            <a href="#approach">Our Approach</a>
            <a href="#faq">FAQ</a>
            <a href="#contact">Contact</a>
          </nav>
          <a href="#contact" className="btn btn-primary" style={{ padding: "9px 18px" }}>
            Get a Quote
          </a>
        </div>
      </header>

      <main id="top">
        <section className="hero">
          <div className="container">
            <span className="eyebrow">Wooden Flooring · Hyderabad</span>
            <h1>Wooden Flooring in Hyderabad, Chosen and Fitted with Care</h1>
            <p className="lead">
              Looking for a floor that suits your rooms, your routine and your budget? We supply
              laminate, engineered wood, solid hardwood, SPC and vinyl wood-look planks, and we
              handle the fitting too.
            </p>
            <div className="hero-actions">
              <a href="#flooring" className="btn btn-primary">
                Browse Floor Types
              </a>
              <a href="#contact" className="btn btn-outline" style={{ color: "#fff" }}>
                Talk to Our Team
              </a>
            </div>
            <div className="hero-badges">
              <span>Honest advice on what suits you</span>
              <span>Careful, tidy fitting</span>
              <span>Straight answers, no pressure</span>
            </div>
          </div>
        </section>

        <section id="flooring">
          <div className="container">
            <div className="section-head">
              <span className="eyebrow">Floor Types</span>
              <h2>Find the Right Wooden Floor for Each Room</h2>
              <p>
                A hard-wearing surface for a busy kitchen, or solid timber for a living room that
                needs warmth. Here is what we supply.
              </p>
            </div>
            <div className="grid">
              {business.services.map((s) => (
                <article className="card" key={s.id}>
                  <div className="card-plank" aria-hidden="true" />
                  <h3>{s.name}</h3>
                  <p>{s.description}</p>
                  <a className="text-link" href="#contact">
                    Ask about this floor →
                  </a>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="approach" className="reasons">
          <div className="container">
            <div className="section-head">
              <span className="eyebrow">Our Approach</span>
              <h2>What Sets Our Service Apart</h2>
            </div>
            <div className="grid">
              {business.reasons.map((r, i) => (
                <div className="reason" key={r.title}>
                  <div className="reason-icon" aria-hidden="true">
                    {reasonIcons[i]}
                  </div>
                  <h3>{r.title}</h3>
                  <p>{r.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="clients">
          <div className="container">
            <div className="section-head" style={{ marginBottom: 0 }}>
              <span className="eyebrow">Our Clients</span>
              <h2>Organisations That Have Trusted Us</h2>
              <p>Hotels and corporate offices across Hyderabad rely on us for their interiors.</p>
            </div>
            <ul className="client-list">
              {business.clients.map((c) => (
                <li key={c}>{c}</li>
              ))}
            </ul>
          </div>
        </section>

        <section id="faq" style={{ background: "var(--paper)" }}>
          <div className="container">
            <div className="section-head">
              <span className="eyebrow">FAQ</span>
              <h2>Common Questions</h2>
            </div>
            <div className="faq">
              {business.faqs.map((f) => (
                <details key={f.question}>
                  <summary>{f.question}</summary>
                  <p>{f.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        <section id="contact" className="contact">
          <div className="container">
            <div className="section-head">
              <span className="eyebrow">Contact</span>
              <h2>Let&apos;s Plan Your Floor</h2>
              <p style={{ color: "#dccbb8" }}>
                Call, message or visit. Our team will help you pick the right floor and send a
                quotation.
              </p>
            </div>

            <div className="contact-grid">
              <div className="contact-card">
                <h3>Phone</h3>
                <a href={`tel:${business.phoneTel}`}>{business.phone}</a>
                <p style={{ margin: 0, opacity: 0.8 }}>Talk to a person who knows the range.</p>
              </div>

              <div className="contact-card">
                <h3>Email</h3>
                {business.emails.map((e) => (
                  <a key={e} href={`mailto:${e}`}>
                    {e}
                  </a>
                ))}
              </div>

              <div className="contact-card">
                <h3>Address</h3>
                <address>
                  {business.address.display.map((line) => (
                    <span key={line} style={{ display: "block" }}>
                      {line}
                    </span>
                  ))}
                </address>
                <a
                  href={MAPS_HREF}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{ marginTop: 10, fontSize: "0.95rem", color: "var(--oak-light)" }}
                >
                  View on Google Maps →
                </a>
              </div>
            </div>

            <div className="contact-actions">
              <a href={`tel:${business.phoneTel}`} className="btn btn-primary">
                Call Us
              </a>
              <a href={WHATSAPP_HREF} target="_blank" rel="noopener noreferrer" className="btn btn-whatsapp">
                Message on WhatsApp
              </a>
              <a href={`mailto:${business.primaryEmail}`} className="btn btn-outline" style={{ color: "#fff" }}>
                Request a Quote by Email
              </a>
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="container">
          <span>
            © {new Date().getFullYear()} {business.name}. Supplying and fitting wooden floors across
            Hyderabad, Telangana.
          </span>
          <span>
            <a href={`tel:${business.phoneTel}`}>{business.phone}</a> ·{" "}
            <a href={`mailto:${business.primaryEmail}`}>{business.primaryEmail}</a>
          </span>
        </div>
      </footer>

      <nav className="mobile-cta" aria-label="Quick contact">
        <a href={`tel:${business.phoneTel}`} className="call">
          Call
        </a>
        <a href={WHATSAPP_HREF} target="_blank" rel="noopener noreferrer" className="wa">
          WhatsApp
        </a>
      </nav>
    </>
  );
}
